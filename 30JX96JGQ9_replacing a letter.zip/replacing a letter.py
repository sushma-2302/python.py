a=input()
b=int(input())
c=input()
first_part=a[0:b]
print(first_part)
last_part=a[b+1:]
print(last_part)
print(first_part+c+last_part)